import { motion } from 'framer-motion'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts"; 

const categoryData = [
    { name: "Communication Services", value: 4500 },
    { name: "Consumer Discretionary", value: 2564 },
    { name: "Consumer Staples", value: 2456 },
    { name: "Energy", value: 7456 },
    { name: "Financials", value: 2344 },
    { name: "Healthcare", value: 9856 },
    { name: "Industrials", value: 5687 },
    { name: "Information Technology", value: 3500 },
    { name: "Materials", value: 4567 },
    { name: "Real Estate", value: 3875 },
    { name: "Utilities", value: 4356 },
]

const COLORS = ["#6366F1", "#8B5CF6", "#EC4899", "#10B981", "#F59E0B", "#3B82F6", "#A855F7", "#D946EF", "#34D399", "#FCD34D", "#F97316"]

const CategoryDistributionChart = () => {
  return (
    <motion.div
    className='bg-gray-800 bg-opacity-50 backdrop-blur-md shadow-lg rounded-xl p-6 border border-gray-700'
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: 0.3 }}
    >

        <h2 className='text-lg font-medium mb-4 text-gray-100'>
        Category Distribution</h2>
        <div className='h-80'>
            <ResponsiveContainer width={'100%'} height={'100%'}>
                <PieChart>
                    <Pie
                    data={categoryData}
                    cx={"50%"}
                    cy={"50%"}
                    LabelLine={false}
                    outerRadius={80}
                    fill='#8884d8'
                    dataKey='value'
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                    {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}

                    </Pie>
                    <Tooltip 
                    contentStyle={{
                        backgroundColor: "rgba(31, 41, 55, 0.8)", 
                        borderColor: "#4B5563",
                        }}
                    itemStyle={{ color: "#E5E7EB" }}
                    />
                </PieChart>
            </ResponsiveContainer>
        </div>

    </motion.div>
  )
}

export default CategoryDistributionChart